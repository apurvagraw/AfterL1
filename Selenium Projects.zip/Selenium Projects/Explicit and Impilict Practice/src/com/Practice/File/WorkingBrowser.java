package com.Practice.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class WorkingBrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//FOR CHORME
		
		System.setProperty("webdriver.chrome.driver","D:/Apurv Agrawal/Module 4 Content/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.google.com/");
		
		//FOR IE
		
		//System.setProperty("webdriver.ie.driver","D:\\IEDriverServer.exe");
		//WebDriver driver=new InternetExplorerDriver();
		//driver.get("http://www.google.com/");
		
	}

}
