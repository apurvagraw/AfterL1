package com.Practice.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MyAlert {

	public void myalert()
	{
		
		String sText;
		WebDriver driver=new FirefoxDriver();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("history.go(0)");
		
		String baseurl="file:///D:/Apurv%20Agrawal/Module%204%20Content/Manish/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/AlertExample.html/";
		driver.get(baseurl);
		sText =js.executeScript("return document.title;").toString();
		System.out.println(sText);
		driver.findElement(By.id("txtName")).sendKeys("Apurv");;

		WebElement t=driver.findElement(By.name("btnAlert"));
		
		//Perform click on show alert box button using javaScriptExcecutor 
		//js.executeScript ("arguments[0].click();,button);
		js.executeScript("alert('hello world');");
	}
	
	
}
