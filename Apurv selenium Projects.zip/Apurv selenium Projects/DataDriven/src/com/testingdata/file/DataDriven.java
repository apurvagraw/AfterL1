package com.testingdata.file;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataDriven extends DataExcel{

	
	WebDriver driver;
	@Test (dataProvider="LoginData")
	public void LoginToShoppingApp(String username, String password)throws InterruptedException
	
	{
		driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("file:///D:/Apurv%20Agrawal/Module%204%20Final/Apurv%20New/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lab%20Files/Lab%20Files/LoginPage.html");
		driver.findElement(By.name("userid")).sendKeys(username);
		driver.findElement(By.name("pswrd")).sendKeys(password);
		driver.findElement(By.xpath("/html/body/form/input[3]")).click();
		Thread.sleep(5000);
		System.out.println(driver.getTitle());
		driver.close();
		
		

	}
	
	@DataProvider(name="LoginData")
	public String[][]datapass() throws Exception
	{
		/*Object[][]data=new Object[3][2];
		data[0][0]="Dayanand";
		data[0][1]="Capgemini";
		data[1][0]="SeleniumUser";
		data[1][1]="selenium123";
		data[2][0]="Ayush";
		data[2][1]="Capgemini";
		*/
		
		//Excel CODE block
		
		DataExcel dataE=new DataExcel();
		
		 String filePath = System.getProperty("user.dir")+"//src//com//testingdata//file";
		 String[][] data=new String[0][1];
 
		data= dataE.readExcel(filePath,"Book1.xlsx","Sheet1");
		
		
		return data;
		

	}
	
	
	
	
	
}

