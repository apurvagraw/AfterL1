package pagefactorydatadriven;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.WebElement;

public class RegisterDemoCart {
	static WebDriver driver;
	 //Locators
	//My Account
	 @FindBy(how = How.XPATH, using = ".//*[@id='top-links']/ul/li[2]/a/span[2]")
	 static WebElement MyAccount;
	 //Register
	 @FindBy(how = How.LINK_TEXT, using = "Register")
	 static WebElement Register;
	 //FirstName
	 @FindBy(how = How.ID, using = "input-firstname")
	 static WebElement FirstName;
	 //LastName
	 @FindBy(how = How.ID, using = "input-lastname")
	 static WebElement LastName;
	 //Email
	 @FindBy(how = How.ID, using = "input-email")
	 static WebElement Email;
	 //Telephone
	 @FindBy(how = How.ID, using = "input-telephone")
	 static WebElement Telephone;
	 //Password
	 @FindBy(how = How.ID, using = "input-password")
	 static WebElement Password;
	 //Confirm Password
	 @FindBy(how = How.ID, using = "input-confirm")
	 static WebElement ConfirmPassword;
	 //NewsLetter
	 @FindBy(how = How.XPATH, using = ".//*[@id='content']/form/fieldset[3]/div/div/label[2]/input")
	 static WebElement Newsletter;
	 //Subscribe
	 @FindBy(how = How.NAME, using = "agree")
	 static WebElement Subscribe;
	 //continue
	 @FindBy(how = How.XPATH, using = " .//*[@id='content']/form/div/div/input[2]")
	 static WebElement Continue;
	 
	 @Test(dataProvider = "data")
	 public void integrationTest(Map<String, String> map) throws InterruptedException {
			// TODO Auto-generated method stub
			driver = new FirefoxDriver();
			//Implicit Wait 
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 
	        driver.get("https://demo.opencart.com/");
	 
	        PageFactory.initElements(driver, RegisterDemoCart.class);
	        //click on Myaccount
	        MyAccount.click();
	        //click on Register
	        Register.click();
	        //Reading firstname from excel sheet
       FirstName.sendKeys(map.get("FirstName"));
       //Reading LastName from excel sheet
       LastName.sendKeys(map.get("LastName"));
       //Reading Email from excel sheet
       Email.sendKeys(map.get("Email"));
       //Reading Telephone from excel sheet
       Telephone.sendKeys(map.get("Telephone"));
       //Reading Password from excel sheet
       Password.sendKeys(map.get("Password"));
       //Reading Confirm Password from excel sheet
      ConfirmPassword.sendKeys(map.get("ConfirmPassword"));
      //click on Newsletter
      Newsletter.click();
      //click on Subscribe
      Subscribe.click();
      //click on continue
      Continue.click();
      //switching to alert to accept the alert
      driver.switchTo().alert().accept();

	}
	 @DataProvider(name = "data")
	  public Object[][] dataSupplier() throws IOException {
	    File file = new File("D://Apurv Agrawal//Module 4 Final//Apurv New//Module4//Apurv selenium Projects//Group1 PLP Project//src//pagefactorydatadriven//RegisterTestData.xlsx");
	  //Create an object of FileInputStream class to read excel file
	    FileInputStream fis = new FileInputStream(file);
	    XSSFWorkbook wb = new XSSFWorkbook(fis);
	    XSSFSheet sheet = wb.getSheetAt(0);
	    wb.close();
	    //Finding the last row in excel sheet
	    int lastRowNum = sheet.getLastRowNum() ;
	    //Finding the last cell in the excel sheet
	    int lastCellNum = sheet.getRow(0).getLastCellNum();
	    Object[][] obj = new Object[lastRowNum][1];
	    //Create a loop over all the rows of excel file to read it
	    for (int i = 0; i < lastRowNum; i++) {
	      Map<Object, Object> datamap = new HashMap<>();
	      for (int j = 0; j < lastCellNum; j++) {
	    	  //read the data from excel sheet
	        datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i+1).getCell(j).toString());
	      }
	      obj[i][0] = datamap;
	    }
	    return  obj;
	  }

}
