package pagefactorydatadriven;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.WebElement;

 
public class LoginDemoCart {
	static WebDriver driver;
	//Locators
	 //My account
	 @FindBy(how = How.XPATH, using = ".//*[@id='top-links']/ul/li[2]/a/span[2]")
	 static WebElement MyAccount;
	 //login
	 @FindBy(how = How.XPATH, using = ".//*[@id='top-links']/ul/li[2]/ul/li[2]/a")
	 static WebElement login;
	 //email
	 @FindBy(how = How.ID, using = "input-email")
	 static WebElement Emailaddress;
    //password
	 @FindBy(how = How.ID, using = "input-password")
	 static WebElement txtbx_Password;
    //login
	 @FindBy(how = How.XPATH, using = ".//*[@id='content']/div/div[2]/div/form/input")
	 static WebElement btn_Login ;
	 //logout
	 @FindBy(how = How.XPATH, using = ".//*[@id='top-links']/ul/li[2]/ul/li[5]/a")
	 static WebElement logout ;
	
  @Test(dataProvider = "data")
  public void integrationTest(Map<String, String> map) throws InterruptedException {
	  driver = new FirefoxDriver();
		 
      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

      driver.get("https://demo.opencart.com/");

      PageFactory.initElements(driver, LoginDemoCart.class);
      //click on myaccount
      MyAccount.click();
      //click on login
      login.click();
      //enter emailaddress
      String data1=map.get("UserName");
      String data2=map.get("Password");
      Emailaddress.sendKeys(data1);
      System.out.println(data1);
      //Enter password
      txtbx_Password.sendKeys(data2);
     //click on login
      btn_Login.click();
      //click on my account
      MyAccount.click();
      //click on logout
      logout.click();
      //close
      driver.quit();
	
  }
  @DataProvider(name = "data")
  public Object[][] dataSupplier() throws IOException {
    File file = new File("D://Apurv Agrawal//Module 4 Final//Apurv New//Module4//Apurv selenium Projects//Group1 PLP Project//src//pagefactorydatadriven//LoginTestData.xlsx");
  //Create an object of FileInputStream class to read excel file
    FileInputStream fis = new FileInputStream(file);
    XSSFWorkbook wb = new XSSFWorkbook(fis);
    XSSFSheet sheet = wb.getSheetAt(0);
    wb.close();
    //Find last row in excel file
    int lastRowNum = sheet.getLastRowNum() ;
    int lastCellNum = sheet.getRow(0).getLastCellNum();
    Object[][] obj = new Object[lastRowNum][1];
    //Create a loop over all the rows of excel file to read it
    for (int i = 0; i < lastRowNum; i++) {
      Map<Object, Object> datamap = new HashMap<>();
      //read the data from excelsheet 
      for (int j = 0; j < lastCellNum; j++) {
        datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i+1).getCell(j).toString());
      }
      obj[i][0] = datamap;
    }
    return  obj;
  }
}