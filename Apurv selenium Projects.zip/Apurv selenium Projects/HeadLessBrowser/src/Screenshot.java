
import org.testng.annotations.Test;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.io.File;


public class Screenshot {

	@Test
	public void takescreenshot() throws Exception
	{
		WebDriver driver;
		driver=new FirefoxDriver();
	driver.get("https://www.opencart.com/");
	this.takesnapshot(driver,"D://test3.png");
	
	}
	
	
	public static void takesnapshot (WebDriver webdriver,String fileWithPath) throws Exception
	{
		TakesScreenshot scrShot =((TakesScreenshot)webdriver);
	
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		
		File DestFile=new File(fileWithPath);
		
		FileUtils.copyFile(SrcFile, DestFile);
	}
}
