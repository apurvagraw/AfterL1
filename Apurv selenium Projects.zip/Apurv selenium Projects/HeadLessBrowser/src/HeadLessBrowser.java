import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;


public class HeadLessBrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("phantomjs.binary.path","D:\\phantomjs.exe");
		//File file= new File("C:\\Program
		//System.setproperty
		WebDriver driver = new PhantomJSDriver();
		
		driver.get("https://demo.opencart.com/");
		
		System.out.println("Page title is:" + driver.getTitle());
		driver.close();
		
	}

}
