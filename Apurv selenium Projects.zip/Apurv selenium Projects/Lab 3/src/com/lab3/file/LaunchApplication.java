package com.lab3.file;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;



public class LaunchApplication {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		
		driver.get("https://demo.opencart.com");
		
		String title = driver.getTitle();
		
		if(title.equals("Your Store"))
			System.out.print("Title is Verified");
		else
		System.out.println("Title is Wrong");
		
		driver.findElement(By.xpath("html/body/nav/div/div[2]/ul/li[2]/a")).click(); 
		Thread.sleep(1000);
		driver.findElement(By.xpath("html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a")).click(); 
		
		String Text1 = driver.findElement(By.xpath("html/body/div[2]/div/div/h1")).getText();
		String Text2 = "Register Account";
		if(Text1.equals(Text2))
			System.out.println("\nHeading is Correct");
		else 
			System.out.println("Heading is InCorrect");
		
		driver.findElement(By.cssSelector("input.btn.btn-primary")).click(); 
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		String Text3 = driver.findElement(By.xpath("html/body/div[2]/div[1]")).getText();
		String Text4 = "Warning: You must agree to the Privacy Policy!";
		if(Text3.equals(Text4))
			System.out.println("\nMessage is Correct");
		else 
			System.out.println("Message is InCorrect");
	}

}
