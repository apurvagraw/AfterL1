package com.practice.file;

import org.testng.annotations.Test;

public class PriorityPractice {

	@Test //(priority=2)
	public void Login()
	{
		System.out.println("Login");
	}
	
	@Test (priority=3)
	public void Ailsend()
	{
		System.out.println("send");
	}
	
	
	
	@Test(priority='b')
	public void Registration()
	{
		System.out.println("Resgistration");
	}
}
