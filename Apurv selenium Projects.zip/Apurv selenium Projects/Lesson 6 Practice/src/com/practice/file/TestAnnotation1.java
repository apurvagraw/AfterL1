package com.practice.file;

import org.junit.Test;

public class TestAnnotation1 {

	@Test
	public void a()
	{
		System.out.println("I am in Display");
	
	}
	
	
	@Test
	public void c()
	{
		System.out.println("I am in Exit");
	
	}
	
	@Test
	public void b()
	{
		System.out.println("I am in Print");
	
	}
}
