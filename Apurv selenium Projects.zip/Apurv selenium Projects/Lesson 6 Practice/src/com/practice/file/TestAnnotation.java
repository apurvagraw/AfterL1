package com.practice.file;

import org.junit.Test;

public class TestAnnotation {

	@Test
	public void a4b4()
	{
		System.out.println("I am in Display");
	
	}
	
	
	@Test
	public void a1b1()
	{
		System.out.println("I am in Exit");
	
	}
	
	@Test
	public void a5b5()
	{
		System.out.println("I am in Print");
	
	}
}
