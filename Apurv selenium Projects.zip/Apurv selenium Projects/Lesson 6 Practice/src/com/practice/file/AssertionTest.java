package com.practice.file;
import static org.junit.Assert.*;


public class AssertionTest {

		
	String str1=new String("abc");
	String str2=new String("abc");
	String str3=new String("abc");
	String str4="abc";
	String str5="abc";
	int val1=6;
	int val2=5;
	String[] expectedarray={"one","two","three"};
	String[] resultarray={"one","two","three"};
	
	//check two objects are equal
	assertEquals(str1,str2);
	//Check the condition is true 
	assertTrue(val1<val2);
	
	//	assertTrue(val1>val2); 
	
	//Check the condition is false 
		assertTrue(val1>val2);
	
	//Check that object is not null 
		assertNotNull(str1);
		
		//Check that object is null 
				assertNotNull(str3);
				
				//Check if the two object references point to the same
				assertSame(str4,str5);
				//Check if the two object references point not to the same
				assertSame(str1,str3);
				//Check wether two arrays are equal to each other
				assertArrayEquals(expectedarray.resultarray);
				

}
	

}
