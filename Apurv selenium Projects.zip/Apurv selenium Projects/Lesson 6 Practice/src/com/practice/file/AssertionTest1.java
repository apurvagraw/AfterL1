package com.practice.file;

import org.testng.annotations.Test;
import static org.testing.AssertJUnit.assertEquals;
public class AssertionTest1 {

	
	
}
