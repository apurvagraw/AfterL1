package com.webQ4.file;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class UsingIE {

	public static WebDriver driver;
	static String baseUrl;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.ie.driver","D:/IEDriverServer.exe");
		
		WebDriver driver = new InternetExplorerDriver();
	    baseUrl = "https://demo.opencart.com/";
	    driver.get(baseUrl + "/");
	    
	    //Verify the Title
	    String Title1 = "Your Store";
		String Title2;
		Title2=driver.getTitle();
		
		if(Title1.contentEquals(Title2))
		{
			System.out.println("The Title is Verified");
			
		}
		else
		{
			System.out.println("Web Page Title does not Verified");
			
		}
	    
	    //Wait for the Page to Load
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  
	    
	    //Verify Number of Links
	    List<WebElement> link = driver.findElements(By.xpath("//a"));    //Identify the number of Link on webpage 
        
        int lCount = link.size();     // Count the total Number of Link on Web Page
        
        System.out.println("Total Number of links on the Given Webpage  = "  + lCount);    //Print the total No. of links
	    

	    //Click on my Account
        driver.findElement(By.xpath("html/body/nav/div/div[2]/ul/li[2]/a")).click();
    
	    
	    //Select Register option
        driver.findElement(By.xpath("html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a")).click();
        
	    
	    //Filling Mandatory Field Except Two Left
        driver.findElement(By.id("input-firstname")).clear();
   		driver.findElement(By.id("input-firstname")).sendKeys("Apurv");
   		//driver.findElement(By.id("input-lastname")).clear();
		//driver.findElement(By.id("input-lastname")).sendKeys(" ");
   		driver.findElement(By.id("input-email")).clear();
   		driver.findElement(By.id("input-email")).sendKeys("Apurv1@gmail.com");
   		//driver.findElement(By.id("input-telephone")).sendKeys(" ");
   		driver.findElement(By.id("input-password")).sendKeys("Hello@12345");
   		driver.findElement(By.id("input-confirm")).sendKeys("Hello@12345");
   		driver.findElement(By.name("agree")).click();
   		driver.findElement(By.cssSelector("input.btn.btn-primary")).click();
	    
   		driver.switchTo().alert().accept();
   		
	    //Verify Error Message For Last Name
   		if(driver.findElement(By.xpath("html/body/div[2]/div/div/form/fieldset[1]/div[3]/div/div")).getText().contentEquals("Last Name must be between 1 and 32 characters!"))
	    {
	    	System.out.println("Last Name Empty Message Verified");
	    }
	    	else
	    	{
	    	System.out.println("Last Name Empty Message Not Verified");
	    	}
	
	    
   		//Verify Error Message For Telephone Number
   		if(driver.findElement(By.xpath("html/body/div[2]/div/div/form/fieldset[1]/div[5]/div/div")).getText().contentEquals("Telephone must be between 3 and 32 characters!"))
	    {
	    	System.out.println("Telephone Number Empty Message Verified");
	    }
	    	else
	    	{
	    	System.out.println("Telephone Number Empty Message Not Verified");
	    	}
	    
   		
   		//Filling All Field 
        driver.findElement(By.id("input-firstname")).clear();
   		driver.findElement(By.id("input-firstname")).sendKeys("Apurv");
   		driver.findElement(By.id("input-lastname")).clear();
		driver.findElement(By.id("input-lastname")).sendKeys("Agrawal");
   		driver.findElement(By.id("input-email")).clear();
   		driver.findElement(By.id("input-email")).sendKeys("Apurv12@gmail.com");
   		driver.findElement(By.id("input-telephone")).sendKeys("9997695292");
   		driver.findElement(By.id("input-password")).sendKeys("Hello@12345");
   		driver.findElement(By.id("input-confirm")).sendKeys("Hello@12345");
   		driver.findElement(By.name("agree")).click();
   		driver.findElement(By.cssSelector("input.btn.btn-primary")).click();
   		
   		
	    //Validating the Correct Email Address
   		String Email=driver.findElement(By.id("input-email")).getText();
   		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";
                 
   				Pattern pat = Pattern.compile(emailRegex);
   				if (Email == null)
   				System.out.println("Email Pattern is Correct ");
   				else
   				System.out.println("Email Pattern is Not Correct");
   		
   		//Validating Telephone is Accepting only 10 Digits
   				
   				String TelNumber=driver.findElement(By.id("input-telephone")).getText();	
   				if(TelNumber.matches("^[7-9][0-9]{9}$")) 
   					System.out.println("Telephone is Accepting only 10 Digits");
   				else 
   					System.out.println("Telephone is Accepting More than 10 Digits");
   				
   	
   				
   		//Validation the Confirm Password
   		   		String Password=driver.findElement(By.id("input-password")).getText();
   		   		String ConfirmPassword=driver.findElement(By.id("input-confirm")).getText();
   			    if(Password.equals(ConfirmPassword))
   			    	System.out.println("Confirm Password is Verified");
   			    	else
   			    	System.out.println("Confirm Password is Not Verified");
   			    	
   			    
   		//Verify Subscribe Radio Button Present On Page
   			 
   			if(driver.findElement(By.xpath("html/body/div[2]/div/div/form/fieldset[3]/div/label")).getText().contentEquals("Subscribe"))
   		    {
   		    	System.out.println("Subscribe Radio Button Is Present Verified");
   		    }
   		    	else
   		    	{
   		    		System.out.println("Subscribe Radio Button Is Present Not Verified");;
   		    	}
   		   		
   		  //Click on Subscribe as NO
   			driver.findElement(By.xpath("(//input[@name='newsletter'])[2]")).click();
   				
   			
   		//Click on Agree Privacy Policy
   			driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div/input[1]")).click();
  
   		   	
   		//Click on Continue Button
   			driver.findElement(By.cssSelector("input.btn.btn-primary")).click();
   			
   			
   		//Wait for Page to Load
   			Thread.sleep(5000);
   			
   		//Verify Account Creation 
   			if(driver.findElement(By.xpath("html/body/div[2]/div/div/h1")).getText().contentEquals("Your Account Has Been Created!"))
   		    {
   		    	System.out.println("Your Account Has Been Created! Heading is Verified");
   		    }
   		    	else
   		    	{
   		    	System.out.println("Your Account Has Been Created! Heading Not Verified");
   		    	}
   		
   		//Click on Phones & PDA
   			driver.findElement(By.linkText("Phones & PDAs")).click();
   			
   		//Ckick on Mobile Icon HTC TOUCH HD
   			driver.findElement(By.cssSelector("div.image > a > img.img-responsive")).click();
   			
   		//Verify Text HTC Touch HD
   			if(driver.findElement(By.xpath("html/body/div[2]/div/div/div/div[2]/h1")).getText().contentEquals("HTC Touch HD"))
   			
   			{
   		    	System.out.println("HTC Touch HD Text is Verified");
   		    }
   		    	else
   		    	{
   		    	System.out.println("HTC Touch HD Text is not Verified");
   		    	}
   				
   			//Navigate Back
   			driver.navigate().back();
   			
   			//Click on Add to Cart Button
   			driver.findElement(By.xpath("html/body/div[2]/div[2]/div/div[2]/div[1]/div/div[2]/div[2]/button[1]")).click();
   			
   			//Verify Success Heading 
   		    if(driver.findElement(By.xpath("html/body/div[2]/div[2]/div/div[2]/div[1]/div/div[2]/div[2]/button[1]")).getText().contentEquals("Success: You have added HTC Touch HD to your shopping cart!"))
   		    {
   		    	System.out.println("Success Message is Verified");
   		    }
   		    	else
   		    	{
   		    	System.out.println("Success Message is Not Verified");
   		    	}
   			
   		//Click on Link Brand Extra
   			driver.findElement(By.linkText("Brands")).click();
   		
   	   /*Verify Find your Favorite Brand Heading
   			
   		 if(driver.findElement(By.cssSelector("#content > h1")).getText().contentEquals("Find Your Favorite Brand"))
			{
				   System.out.println("Find Your Brand Heading Verified");
				 }
				else
				{
				System.out.println("Find Your Brand Heading Failed");
				}
   			*/
   		 
   		 //Verify the Title of Current Page
 	    String Title3 = "Find Your Favorite Brand";
 		String Title4;
 		Title4=driver.getTitle();
 		
 		if(Title3.contentEquals(Title4))
 		{
 			System.out.println("The Title is Verified");
 			
 		}
 		else
 		{
 			System.out.println("Web Page Title does not Verified");
 			
 		}
   		 
 		
 		
 		//Click on Cannon C option 
 		
			driver.findElement(By.linkText("Canon")).click();
			
		//Verify Heading Cannon 
			if(driver.findElement(By.xpath("html/body/div[2]/div/div/h2")).getText().contentEquals("Canon"))
			{
			   System.out.println("Your Cannon Heading Verified");
			 }
			else
			{
			System.out.println("Your Cannon Heading Verification Failed");
			}
	   
 		
 		//Click on Add to wish List
			driver.findElement(By.xpath("(//button[@type='button'])[11]")).click();
 		
		//Verifying the Message
			//Verify Success Heading 
   		    if(driver.findElement(By.xpath("html/body/div[2]/div[1]")).getText().contentEquals("Success: You have added Canon EOS 5D to your wish list!"))
   		    {
   		    	System.out.println("Success Message is Verified");
   		    }
   		    	else
   		    	{
   		    	System.out.println("Success Message is Not Verified");
   		    	}
		
   		   //Verify the message
   			if(driver.findElement(By.xpath("html/body/div[2]/div[1]")).getText().contentEquals("Success: You have added Canon EOS 5D to your wish list!"))
   		    {
   		    	System.out.println("Wish list success message Verified");
   		    }
   		    else
   		    {
   		    	System.out.println("Wish list success message Validation Failed");
   		   	}
   			
   			//Click on wishlist under my account option 
   			driver.findElement(By.linkText("Wish List")).click();
   			
   			
   			//Verify wishList Title
   			String Title5 = "My Wish List";
   			String Title6;
   			Title6=driver.getTitle();
   			
   			if(Title5.contentEquals(Title6))
   			{
   				System.out.println("My Wish List Title is Verified");
   				
   			}
   			else
   			{
   				System.out.println("Web Page Title not Verified");
   				
   			}
   			
   			
   			//Wait for continue button papers on page
   			Thread.sleep(5000);
   			
   			
   			//Click on the continue button
   			driver.findElement(By.xpath("html/body/div[2]/div/div/div[2]/div/a")).click();

 		
   			
   			//Close The Browser
   			driver.quit();
   			
   			
   			
	}
	}