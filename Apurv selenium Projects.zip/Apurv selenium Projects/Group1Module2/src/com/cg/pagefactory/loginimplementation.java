package com.cg.pagefactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.openqa.selenium.support.PageFactory;

public class loginimplementation {
	static WebDriver driver;
	 @Test(dataProvider = "data")
	  public void integrationTest(Map<String, String> map) throws InterruptedException {
		  driver = new FirefoxDriver();
			 
	      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	      driver.get("https://demo.opencart.com/");

	      PageFactory.initElements(driver, LoginHashmap.class);
	      LoginHashmap a= new LoginHashmap();
		//click on myaccount
	     a. MyAccount.click();
	      //click on login
	      a.login.click();
	      //enter emailaddress
	      String data1=map.get("UserName");
	      String data2=map.get("Password");
	      a.Emailaddress.sendKeys(data1);
	      System.out.println(data1);
	      //Enter password
	      a.txtbx_Password.sendKeys(data2);
	     //click on login
	     a. btn_Login.click();
	      //click on my account
	      a.MyAccount.click();
	      //click on logout
	     a. logout.click();
	      //close
	      driver.quit();
		
	  }
	  @DataProvider(name = "data")
	  public Object[][] dataSupplier() throws IOException {
	    File file = new File("D://Apurv Agrawal//Module 4 Final//Apurv New//Module4//Apurv selenium Projects//Group1Module2//src//com//cg//pagefactory//Book1.xlsx");
	  //Create an object of FileInputStream class to read excel file
	    FileInputStream fis = new FileInputStream(file);
	    XSSFWorkbook wb = new XSSFWorkbook(fis);
	    XSSFSheet sheet = wb.getSheetAt(0);
	    wb.close();
	    //Find last row in excel file
	    int lastRowNum = sheet.getLastRowNum() ;
	    int lastCellNum = sheet.getRow(0).getLastCellNum();
	    Object[][] obj = new Object[lastRowNum][1];
	    //Create a loop over all the rows of excel file to read it
	    for (int i = 0; i < lastRowNum; i++) {
	      Map<Object, Object> datamap = new HashMap<>();
	      //read the data from excelsheet 
	      for (int j = 0; j < lastCellNum; j++) {
	        datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i+1).getCell(j).toString());
	      }
	      obj[i][0] = datamap;
	    }
	    return  obj;
	  }
	
}
