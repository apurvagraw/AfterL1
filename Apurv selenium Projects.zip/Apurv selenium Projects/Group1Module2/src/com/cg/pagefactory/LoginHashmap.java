package com.cg.pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginHashmap {
	 @FindBy(how = How.XPATH, using = ".//*[@id='top-links']/ul/li[2]/a/span[2]")
	  WebElement MyAccount;
	 //login
	 @FindBy(how = How.XPATH, using = ".//*[@id='top-links']/ul/li[2]/ul/li[2]/a")
	  WebElement login;
	 //email
	 @FindBy(how = How.ID, using = "input-email")
	  WebElement Emailaddress;
    //password
	 @FindBy(how = How.ID, using = "input-password")
	 WebElement txtbx_Password;
    //login
	 @FindBy(how = How.XPATH, using = ".//*[@id='content']/div/div[2]/div/form/input")
	  WebElement btn_Login ;
	 //logout
	 @FindBy(how = How.XPATH, using = ".//*[@id='top-links']/ul/li[2]/ul/li[5]/a")
	  WebElement logout ;
	
}
